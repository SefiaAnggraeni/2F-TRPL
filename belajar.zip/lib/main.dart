import 'package:flutter/material.dart';
import 'package:belajar/ui/produk_form.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      title: 'Form Input Data',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const ProdukForm(),
    );
  }
}
