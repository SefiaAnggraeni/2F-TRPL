package com.example.oktober20

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
