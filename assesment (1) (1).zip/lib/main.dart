import 'package:flutter/material.dart';
import '14proone.dart'; // Import file 14proone.dart
import '14protwo.dart'; // Import file 14protwo.dart

void main() {
  runApp(const FigmaToCodeApp());
}

class FigmaToCodeApp extends StatelessWidget {
  const FigmaToCodeApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color.fromARGB(255, 18, 32, 47),
      ),
      home: Scaffold(
        body: ListView(
          children: [
            FigmaToCodeApp(),
            FigmaToCodeApp(),
          ],
        ),
      ),
    );
  }
  /*Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(useMaterial3: true),
      home: const FigmaToCodeApp(),
      debugShowCheckedModeBanner: false,
    );
  }*/
}
