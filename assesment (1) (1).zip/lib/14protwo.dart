import 'package:flutter/material.dart';

void main() {
  runApp(const FigmaToCodeApp());
}

class FigmaToCodeApp extends StatelessWidget {
  const FigmaToCodeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color.fromARGB(255, 18, 32, 47),
      ),
      home: Scaffold(
        body: ListView(children: [
          Iphone14Plus2(),
        ]),
      ),
    );
  }
}

class Iphone14Plus2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 428,
          height: 926,
          clipBehavior: Clip.antiAlias,
          decoration: BoxDecoration(color: Colors.white),
          child: Stack(
            children: [
              Positioned(
                left: 71,
                top: 62,
                child: SizedBox(
                  width: 255,
                  child: Text(
                    'LIST PERSONAL DATA',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontFamily: 'Chivo',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 20,
                top: 129,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 20,
                top: 365,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 20,
                top: 247,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 20,
                top: 483,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 37,
                top: 414,
                child: Container(
                  width: 380,
                  height: 4,
                  decoration: BoxDecoration(color: Colors.white),
                ),
              ),
              Positioned(
                left: 20,
                top: 601,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 20,
                top: 719,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 37,
                top: 650,
                child: Container(
                  width: 380,
                  height: 4,
                  decoration: BoxDecoration(color: Colors.white),
                ),
              ),
              Positioned(
                left: 20,
                top: 837,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 20,
                top: 955,
                child: Container(
                  width: 373,
                  height: 97,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 0,
                        top: 0,
                        child: Container(
                          width: 373,
                          height: 97,
                          decoration: ShapeDecoration(
                            color: Color(0xFFFCFCFC),
                            shape: RoundedRectangleBorder(
                                side: BorderSide(width: 1)),
                            shadows: [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 11,
                        child: Text(
                          'Presiden Jokowi',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 52,
                        child: Text(
                          'Jalan Raya Jember No.KM13, Kawang, Labanasem,\n Kec. Kabat, Kabupaten Banyuwangi, Jawa Timur',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                      Positioned(
                        left: 17,
                        top: 34,
                        child: Text(
                          'Email : jokowi@indonesia.com',
                          style: TextStyle(
                            color: Color(0xFF4A3CE4),
                            fontSize: 10,
                            fontFamily: 'Chivo',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 37,
                top: 886,
                child: Container(
                  width: 380,
                  height: 4,
                  decoration: BoxDecoration(color: Colors.white),
                ),
              ),
              Positioned(
                left: 20,
                top: 62,
                child: Container(
                  width: 34,
                  height: 24,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage("https://via.placeholder.com/34x24"),
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
